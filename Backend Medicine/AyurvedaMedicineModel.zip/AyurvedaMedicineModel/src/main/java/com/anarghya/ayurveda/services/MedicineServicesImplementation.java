package com.anarghya.ayurveda.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anarghya.ayurveda.model.Medicine;
import com.anarghya.ayurveda.repository.MedicineRepository;
/****************************
 * @Service: It is used with classes that provide some business functionalities.
 ****************************/
@Service
public class MedicineServicesImplementation implements MedicineServices {

	/****************************
	 * @Autowired: It allows Spring to resolve and inject collaborating beans into
	 *             our bean.
	 ****************************/
	@Autowired
	private MedicineRepository medicineRepository;

	@Override
	public List<Medicine> getAllMedicines() {
        return medicineRepository.findAll();
    }

	@Override
	public Medicine getMedicineById(Long id) {
        return medicineRepository.findById(id).orElse(null);
    }
	@Override
	 public Medicine addMedicine( Medicine medicine) {
        return medicineRepository.save(medicine);
    }
	@Override
	public Medicine updateMedicine(Long id, Medicine updatedMedicine) {
		updatedMedicine.setId(id);
		return medicineRepository.save(updatedMedicine);
	}

	@Override
	 public void deleteMedicine(Long id) {
        medicineRepository.deleteById(id);
    }

}
