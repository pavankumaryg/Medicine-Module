package com.anarghya.ayurveda.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/*@Entity: defines that said class is an entity and will be mapped to a database table.*/
@Entity
/*
 * @Table: allows us to specify the details of the table that will be used to
 * persist the entity in the database.
 */
@Table(name = "medicines")
public class Medicine {
	
	/* @Id: specifies the primary key of an entity. */
	@Id
	/*
	 * specifies that the primary key values for User entities should be generated
	 * using an identity column in the database.
	 */
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String mfdDate;
	private String expiryDate;
	private float cost;
	private String company;
	private String category;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMfdDate() {
		return mfdDate;
	}

	public void setMfdDate(String mfdDate) {
		this.mfdDate = mfdDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Medicine(Long id, String name, String mfdDate, String expiryDate, float cost, String company,
			String category) {
		this.id = id;
		this.name = name;
		this.mfdDate = mfdDate;
		this.expiryDate = expiryDate;
		this.cost = cost;
		this.company = company;
		this.category = category;
	}

	public Medicine() {

	}

}
