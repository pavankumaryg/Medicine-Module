package com.anarghya.ayurveda.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.anarghya.ayurveda.model.Customer;
import com.anarghya.ayurveda.repository.CustomerRepository;
/****************************
 * @Service: It is used with classes that provide some business functionalities.
 ****************************/
@Service
public class CustomerServisesImplementation implements CustomerServices {

	/****************************
	 * @Autowired: It allows Spring to resolve and inject collaborating beans into
	 *             our bean.
	 ****************************/
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public ResponseEntity<String> registerUser(Customer customer) {
		// Check if the email is already registered or not
		if (customerRepository.findByEmail(customer.getEmail()).isPresent()) {
			return ResponseEntity.badRequest().body("Email is already registered.");
		}
		// if email is not registered then it going to save the data
		customerRepository.save(customer);
		return ResponseEntity.ok("Registration successful.");

	}

	@Override
	public List<Customer> getAllCustomers() {
		return customerRepository.findAll();
	}

	@Override
	public ResponseEntity<String> loginUser(Customer customer) {
		Optional<Customer> customerOptional = customerRepository.findByEmail(customer.getEmail());

		// checks that user email present or not
		if (!customerOptional.isPresent()) {
			return ResponseEntity.badRequest().body("Customer not found.");
		}

		Customer customer2 = customerOptional.get();
		// if email is present then it going to compare the password
		if (!customer2.getPassword().equals(customer.getPassword())) {
			return ResponseEntity.badRequest().body("Incorrect password.");
		}

		return ResponseEntity.ok("Login successful.");
	}

}
