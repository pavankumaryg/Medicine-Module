package com.anarghya.ayurveda.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anarghya.ayurveda.model.Customer;
import com.anarghya.ayurveda.services.CustomerServisesImplementation;

/****************************
 * @CrossOrigin: enables cross-origin resource sharing only for this specific
 *               method
 ****************************/
@CrossOrigin(origins = "http://localhost:3000")
/****************************
 * @RestController: to simplify the creation of RESTful web services
 ****************************/
@RestController
/****************************
 * @RequestMapping: which is used to map HTTP requests to handler methods of MVC
 *                  and REST controllers
 ****************************/
@RequestMapping("/api")
public class CustomerController {

	/****************************
	 * @Autowired: It allows Spring to resolve and inject collaborating beans into
	 *             our bean.
	 ****************************/
	@Autowired
	CustomerServisesImplementation implementation;

	/****************************
	 * Method: registerUser: It is used to do add the Customer Details if email is
	 * already present it will return error message
	 * 
	 * @returns It returns the message like successful or not
	 * @PostMapping: It is used to map HTTP POST requests onto specific handler
	 *               methods.
	 * @RequestBody: It used to maps the HttpRequest body to a transfer or domain
	 *               object, enabling automatic deserialization of the inbound
	 *               HttpRequest body onto a Java object.
	 ****************************/
	@PostMapping("/register")
	public ResponseEntity<String> registerUser(@RequestBody Customer customer) {
		return implementation.registerUser(customer);
	}

	/****************************
	 * Method: getAllCustomerDetails: It is used to view all categories
	 * 
	 * @returns It returns list of Customers with details
	 * @GetMapping: It is used to handle the HTTP POST requests matched with given
	 *              URI expression.
	 ****************************/
	@GetMapping("/register")
	public List<Customer> getAllCustomersDetails() {
		return implementation.getAllCustomers();
	}

	/****************************
	 * Method: loginUser: It is used for validation by email
	 * 
	 * @returns It returns the message like successful or not
	 * @PostMapping: It is used to map HTTP POST requests onto specific handler
	 *               methods.
	 * @RequestBody: It used to maps the HttpRequest body to a transfer or domain
	 *               object, enabling automatic deserialization of the inbound
	 *               HttpRequest body onto a Java object.
	 ****************************/
	@PostMapping("/login")
	public ResponseEntity<String> loginUser(@RequestBody Customer customer) {
		return implementation.loginUser(customer);
	}

}
