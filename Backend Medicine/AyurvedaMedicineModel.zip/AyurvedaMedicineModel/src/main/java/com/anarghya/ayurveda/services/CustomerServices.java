package com.anarghya.ayurveda.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.anarghya.ayurveda.model.Customer;

public interface CustomerServices {

	public ResponseEntity<String> registerUser(Customer customer);

	public List<Customer> getAllCustomers();

	public ResponseEntity<String> loginUser(Customer customer);
}
