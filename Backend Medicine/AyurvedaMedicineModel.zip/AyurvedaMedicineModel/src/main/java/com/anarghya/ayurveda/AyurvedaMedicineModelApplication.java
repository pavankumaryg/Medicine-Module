package com.anarghya.ayurveda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AyurvedaMedicineModelApplication {

	public static void main(String[] args) {
		SpringApplication.run(AyurvedaMedicineModelApplication.class, args);
	}

}
