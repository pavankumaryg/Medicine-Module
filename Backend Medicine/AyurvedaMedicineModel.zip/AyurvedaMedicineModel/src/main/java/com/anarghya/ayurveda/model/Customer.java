package com.anarghya.ayurveda.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/*@Entity: defines that said class is an entity and will be mapped to a database table.*/
@Entity
/*
 * @Table: allows us to specify the details of the table that will be used to
 * persist the entity in the database.
 */
@Table(name = "customer")
public class Customer {

	/* @Id: specifies the primary key of an entity. */
	@Id
	/*
	 * specifies that the primary key values for User entities should be generated
	 * using an identity column in the database.
	 */
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String email;
	private String fullName;
	private String address;
	private String password;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Customer(Long id, String email, String fullName, String address, String password) {
		this.id = id;
		this.email = email;
		this.fullName = fullName;
		this.address = address;
		this.password = password;
	}

	public Customer() {

	}

}
