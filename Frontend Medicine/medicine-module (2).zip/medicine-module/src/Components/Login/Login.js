import './Login.css';
import React, { useState } from 'react';
import { Link, useHistory } from 'react-router-dom'; // Import useHistory

function Login() {
  const [loginData, setLoginData] = useState({
    email: '',
    password: '',
  });

  const [loginStatus, setLoginStatus] = useState(null);
  const history = useHistory(); // Get the history object

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setLoginData({ ...loginData, [name]: value });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const response = await fetch('http://localhost:2027/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(loginData),
      });

      if (response.ok) {
        setLoginStatus('Login successful.');
        // Redirect the user to the medicineUser component
        history.push('/Medicine');
      } else {
        const data = await response.json();
        setLoginStatus(data);
      }
    } catch (error) {
      console.error('Error:', error);
      setLoginStatus('invalid email or password.');
    }
  };

  return (
    
    <div>
      <div className='navv'>
      <nav>
       <a href='./Home'>Back</a>
      </nav>
      </div>
      
      <h2>User Login</h2>
      <form onSubmit={handleSubmit} className="login-user">
        <label>Email:</label>
        <br />
        <input
          type="email"
          name="email"
          placeholder="Enter your email"
          value={loginData.email}
          onChange={handleInputChange}
          required
        />
        <br />
        <label>Password:</label>
        <br />
        {/* <input
          type="password"
          name="password"
          placeholder="Enter your Password"
          value={loginData.password}
          onChange={handleInputChange}
          required
        /> */}
        <input
          type="password"
          name="password"
          placeholder="Enter your Password"
          value={loginData.password}
          onChange={handleInputChange}
          pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$"
          title="Password must contain at least one digit, one lowercase letter, one uppercase letter, one special character, and be at least 8 characters long."
          required
        />


        <button type="submit">Login</button>
        <h4>
          Don't have an Account ?<Link className="link1" to="/Registration">
            &nbsp;Register Now
          </Link>
        </h4>
        <div className="login-status-button">
         {loginStatus && <div>{loginStatus}</div>}
        </div>
      </form>

      
    </div>
  );
}

export default Login;
