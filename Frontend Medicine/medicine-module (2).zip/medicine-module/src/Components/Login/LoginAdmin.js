import './LoginAdmin.css';
import React, { useState } from 'react';
import { useHistory } from 'react-router-dom'; // Import useHistory

function LoginAdmin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginStatus, setLoginStatus] = useState('');
  const history = useHistory(); // Get the history object

  const handleLogin = () => {
    // Hardcoded admin credentials for demonstration purposes
    const hardcodedEmail = 'admin123@gmail.com';
    const hardcodedPassword = '123admin';

    if (email === hardcodedEmail && password === hardcodedPassword) {
      // Successful login
      setLoginStatus('Login successful');
      // Redirect to AddMedicine component
      history.push('/AddMedicine');
    } else {
      // Failed login
      setLoginStatus('Invalid email or password');
    }
  };

  return (
    <div>
      <div className='admin-nav'>
        <nav>
          <a href='./Home'>Back</a>
        </nav>
      </div>
      <h2>Admin Login</h2>
      <form className='login-admin'>
        <div>
          <label>Email:</label><br/>
          <input
            type="email"
            value={email}
            placeholder='Enter your email'
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Password:</label><br/>
          <input
            type="password"
            placeholder='Enter your password'
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button className='admin-button' type="button" onClick={handleLogin}>
          Login
        </button>
        <p className="login-status-button">{loginStatus}</p>
      </form>
     
    </div>
  );
}

export default LoginAdmin;
