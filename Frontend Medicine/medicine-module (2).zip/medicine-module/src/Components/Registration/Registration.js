// Registration.js
import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import './Registration.css';

function Registration() {
  const [formData, setFormData] = useState({
    email: '',
    fullName: '',
    address: '',
    password: ''
  });

  const [registrationStatus, setRegistrationStatus] = useState(null);
  const history = useHistory(); // Get the history object

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const response = await fetch('http://localhost:2027/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setRegistrationStatus('Registration successful.');
        setFormData({
          email: '',
          fullName: '',
          address: '',
          password: '',
        });

        // Redirect to the Login page
        history.push('/Login');
      } else {
        const data = await response.json();
        setRegistrationStatus(data);
      }
    } catch (error) {
      console.error('Error:', error);
      setRegistrationStatus('Registration failed.');
    }
  };

  return (
    <div>
       <div className='navv'>
      <nav>
       <a href='./Login'>Back</a>
      </nav>
      </div>
      <h2>Registration</h2>
      <form onSubmit={handleSubmit} className='register'>
        <label>Email:</label><br />
        <input
          type="email"
          name="email"
          placeholder='Enter your email'
          value={formData.email}
          onChange={handleInputChange}
          required
        />
        <br />
        <label>Full Name:</label><br />
        <input
          type="text"
          name="fullName"
          placeholder='Enter your full Name'
          value={formData.fullName}
          onChange={handleInputChange}
          required
        />
        <br />
        <label>Address:</label><br />
        <input
          type="text"
          name="address"
          placeholder='Enter your Address'
          value={formData.address}
          onChange={handleInputChange}
          required
        />
        <br />
        <label>Password:</label><br />
       
        <input
          type="password"
          name="password"
          placeholder="Enter your Password"
          value={formData.password}
          onChange={handleInputChange}
          pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$"
          title="Password must contain at least one digit, one lowercase letter, one uppercase letter, one special character, and be at least 8 characters long."
          required
        />

        <button type="submit">Register</button>
        {registrationStatus && <div className='status'>{registrationStatus}</div>}
      </form>
    </div>
  );
}

export default Registration;
