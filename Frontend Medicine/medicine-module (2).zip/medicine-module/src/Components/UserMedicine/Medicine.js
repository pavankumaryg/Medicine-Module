// MedicineList.js
import React, { useState, useEffect } from 'react';
import './Medicine.css';

const Medicine = () => {
    const [medicines, setMedicines] = useState([]);
    const [cartMessage, setCartMessage] = useState('');

    useEffect(() => {
        // Fetch medicines from the backend API and set them in the state
        fetch('http://localhost:2027/api/medicines')
            .then((response) => response.json())
            .then((data) => setMedicines(data));
    }, []);

    const addToCart = (medicineName) => {
        // Simulate adding to the cart here (you'd have to implement this logic)
        // You can use state management libraries like Redux for more complex cart handling
        setCartMessage(`Added ${medicineName} to the cart successfully.`);
    };

    return (
        <div>
            <div className='user-medicine'>
            <nav>
            <a href='./Home'>Logout</a>
            </nav>
            </div>
            <h2>Medicine List</h2>
            <div>
            {cartMessage && <p className="alert alert-success">{cartMessage}</p>}
            </div>
            <table className='table-user'>
            <thead>
                    <tr>
                        <th>Name</th>
                        <th>Manufacture Date</th>
                        <th>Expiry Date</th>
                        <th>Cost</th>
                        <th>Company</th>
                        <th>Category</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {medicines.map(medicine => (
                        <tr key={medicine.id}>
                            <td>{medicine.name}</td>
                            <td>{medicine.mfdDate}</td>
                            <td>{medicine.expiryDate}</td>
                            <td>{medicine.cost}</td>
                            <td>{medicine.company}</td>
                            <td>{medicine.category}</td>
                            <td>
                            <button className='btn-user' onClick={() => addToCart(medicine.name)}>Add to Cart</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default Medicine;
