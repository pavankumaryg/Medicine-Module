import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './MedicineList.css';

const MedicineList = () => {
  const [medicines, setMedicines] = useState([]);
  const [selectedMedicine, setSelectedMedicine] = useState(null);
  const [updateMedicine, setUpdateMedicine] = useState(null); // Updated to null
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Function to fetch medicines from the backend
  const fetchMedicines = () => {
    axios.get('http://localhost:2027/api/medicines')
      .then(response => {
        setMedicines(response.data);
      })
      .catch(error => {
        console.error('Error fetching medicines:', error);
      });
  };

  // Function to handle medicine selection for viewing
  const handleViewClick = (medicine) => {
    setSelectedMedicine(medicine);
  };

  // Function to handle medicine selection for updating
  const handleUpdateClick = (medicine) => {
    setUpdateMedicine(medicine); // Set updateMedicine to the selected medicine
    setSelectedMedicine(null); // Clear the selected medicine for viewing
  };

  // Function to handle medicine update
  const handleMedicineUpdate = () => {
    axios.put(`http://localhost:2027/api/medicines/${updateMedicine.id}`, updateMedicine)
      .then(response => {
        setSuccessMessage('Medicine updated successfully.');
        setUpdateMedicine(null); // Clear the updateMedicine state
        fetchMedicines(); // Refresh the medicine list
      })
      .catch(error => {
        setErrorMessage('Error updating medicine.');
        console.error('Error updating medicine:', error);
      });
  };

  // Function to handle medicine deletion
  const handleMedicineDelete = (medicineId) => {
    axios.delete(`http://localhost:2027/api/medicines/${medicineId}`)
      .then(() => {
        setSuccessMessage('Medicine deleted successfully.');
        setMedicines(prevMedicines => prevMedicines.filter(med => med.id !== medicineId));
        setSelectedMedicine(null);
      })
      .catch(error => {
        setErrorMessage('Error deleting medicine.');
        console.error('Error deleting medicine:', error);
      });
  };

  // Fetch medicines when the component mounts
  useEffect(() => {
    fetchMedicines();
  }, []);

  return (
    <div className='medicine-list-all'>
      <div className='medicine-list-nav'>
        <nav>
          <a href="./AddMedicine">AddMedicine</a>
          <a href="#">MedicineList</a>
          <a href="./Home">Logout</a>
        </nav>
      </div>

      {selectedMedicine && !updateMedicine && (
        <div className="medicine-details">
          <h2>View Medicine Details</h2>
          <p><strong>Name:</strong> {selectedMedicine.name}</p>
          <p><strong>Manufacture Date:</strong> {selectedMedicine.mfdDate}</p>
          <p><strong>Expiry Date:</strong> {selectedMedicine.expiryDate}</p>
          <p><strong>Cost:</strong> {selectedMedicine.cost}</p>
          <p><strong>Company:</strong> {selectedMedicine.company}</p>
          <p><strong>Category:</strong> {selectedMedicine.category}</p>
          <button onClick={() => setSelectedMedicine(null)} className='close-button'>Close</button>
        </div>
      )}

      {updateMedicine && (
        <div className="medicine-update">
          <h2>Update Medicine</h2>
                    <form>
                        <div className="form-group">
                            <label>Medicine Name:</label> <br/>
                            <input
                                type="text"
                                name="name"
                                value={updateMedicine.name}
                                onChange={e => setUpdateMedicine({ ...updateMedicine, name: e.target.value })}
                                className="form-control"
                            />
                        </div>
                        <div className="form-group">
                            <label>Manufacture Date:</label><br/>
                            <input
                                type="text"
                                name="mfdDate"
                                value={updateMedicine.mfdDate}
                                onChange={e => setUpdateMedicine({ ...updateMedicine, mfdDate: e.target.value })}
                                className="form-control"
                            />
                        </div>
                        <div className="form-group">
                            <label>Expiry Date:</label><br/>
                            <input
                                type="text"
                                name="expiryDate"
                                value={updateMedicine.expiryDate}
                                onChange={e => setUpdateMedicine({ ...updateMedicine, expiryDate: e.target.value })}
                                className="form-control"
                            />
                        </div>
                        <div className="form-group">
                            <label>Medicine Cost:</label><br/>
                            <input
                                type="text"
                                name="cost"
                                value={updateMedicine.cost}
                                onChange={e => setUpdateMedicine({ ...updateMedicine, cost: e.target.value })}
                                className="form-control"
                            />
                        </div>
                        <div className="form-group">
                            <label>Medicine Company:</label><br/>
                            <input
                                type="text"
                                name="company"
                                value={updateMedicine.company}
                                onChange={e => setUpdateMedicine({ ...updateMedicine, company: e.target.value })}
                                className="form-control"
                            />
                        </div>
                        <div className="form-group">
                            <label>Medicine Category:</label><br/>
                            <input
                                type="text"
                                name="category"
                                value={updateMedicine.category}
                                onChange={e => setUpdateMedicine({ ...updateMedicine, category: e.target.value })}
                                className="form-control"
                            />
                        </div>
                        <button type="button"  onClick={handleMedicineUpdate} className='update-button'>
                            Update Medicine
                        </button>
                    </form>
        </div>
      )}


      <h2>Medicine List</h2>
      {successMessage && <div className="alert alert-success">{successMessage}</div>}
      {errorMessage && <div className="alert alert-danger">{errorMessage}</div>}
      <table className="medicine-list-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Manufacture Date</th>
            <th>Expiry Date</th>
            <th>Cost</th>
            <th>Company</th>
            <th>Category</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {medicines.map(medicine => (
            <tr key={medicine.id}>
              <td>{medicine.name}</td>
              <td>{medicine.mfdDate}</td>
              <td>{medicine.expiryDate}</td>
              <td>{medicine.cost}</td>
              <td>{medicine.company}</td>
              <td>{medicine.category}</td>
              <td>
                <button
                  className="medicine-view-button"
                  onClick={() => handleViewClick(medicine)}
                >
                  View
                </button>
                <button
                  className="medicine-update-button"
                  onClick={() => handleUpdateClick(medicine)}
                >
                  Update
                </button>
                <button
                  className="medicine-delete-button"
                  onClick={() => handleMedicineDelete(medicine.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      
    </div>
  );
};

export default MedicineList;
