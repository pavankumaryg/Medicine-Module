import React, { useState } from 'react';
import axios from 'axios';
import './AddMedicine.css';

function AddMedicine() {
        const [medicine, setMedicine] = useState({
            name: '',
            mfdDate: '',
            expiryDate: '',
            cost: '',
            company: '',
            category: ''
        });

        const [message, setMessage] = useState('');
        const [error, setError] = useState('');
    
        const handleChange = (e) => {
            const { name, value } = e.target;
            setMedicine({ ...medicine, [name]: value });
        };
    
        const handleSubmit = (e) => {
            e.preventDefault();
            axios.post('http://localhost:2027/api/medicines', medicine)
                .then(response => {
                    setMessage('Medicine added successfully.');
                    setError('');
                    setMedicine({
                        name: '',
                        mfdDate: '',
                        expiryDate: '',
                        cost: '',
                        company: '',
                        category: ''
                    });
                })
                .catch(error => {
                    setMessage('');
                    setError('Error adding medicine: ' + error.message);
                });
        };
        return (
            <div className='medicine-form'>
                 <div className='medicine-nav'>
                <nav>
                <a href="#">AddMedicine</a>
                <a href="./MedicineList">MedicineList</a>
                <a href="./Home">Logout</a>
                </nav>
                </div>                            
                <div>
            </div>
                <h2>Add Medicine</h2>
                <form onSubmit={handleSubmit} className='medicine-form1'>
                    <div className="form-group">
                        <label>Medicine Name:</label> <br/>
                        <input
                            type="text"
                            name="name"
                            placeholder='Enter the Medicine Name'
                            value={medicine.name}
                            onChange={handleChange}
                            className="form-control"
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Manufacture Date:</label> <br/>
                        <input
                            type="text"
                            name="mfdDate"
                            placeholder='Enter the Manufactured Date'
                            value={medicine.mfdDate}
                            onChange={handleChange}
                            className="form-control"
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Expiry Date:</label> <br/>
                        <input
                            type="text"
                            name="expiryDate"
                            placeholder='Enter the Expiry Date'
                            value={medicine.expiryDate}
                            onChange={handleChange}
                            className="form-control"
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Medicine Cost:</label>  <br/>
                        <input
                            type="text"
                            name="cost"
                            placeholder='Enter the Medicine Cost'
                            value={medicine.cost}
                            onChange={handleChange}
                            className="form-control"
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Medicine Company:</label>  <br/>
                        <input
                            type="text"
                            name="company"
                            placeholder='Enter the Medicine Company'
                            value={medicine.company}
                            onChange={handleChange}
                            className="form-control"
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Medicine Category:</label>  <br/>
                        <input
                            type="text"
                            name="category"
                            placeholder='Enter the Medicine Category'
                            value={medicine.category}
                            onChange={handleChange}
                            className="form-control"
                            required
                        />
                    </div>
                    <button type="submit" className="medicine-add-button">Add Medicine</button>
                    {message && <div className="alert alert-success">{message}</div>}
                    {error && <div className="alert alert-danger">{error}</div>}
            
                </form>
                 </div>
        );
    };
    
export default AddMedicine;
