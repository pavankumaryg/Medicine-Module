import React, { useState } from 'react';
import './Home.css';

function Home() {
  
  return (
    <div className='image-home'>
      <nav>
        <div className="company-name">Ayurvedic Medicines</div>
        <a href='/Login'>User Login</a>
        <a href='/LoginAdmin'>Admin Login</a>
      </nav>
      <div className='para'>
        <h1>Welcome to Ayurvedic Medicines</h1>
        {/* Add other content for your home page */}
      </div>
    </div>
  );
}

export default Home;
