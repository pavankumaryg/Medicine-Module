import React from 'react';
// import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './Components/Home/Home';
import Login from './Components/Login/Login';
import LoginAdmin from './Components/Login/LoginAdmin';
import Registration from './Components/Registration/Registration';
import Medicine from './Components/UserMedicine/Medicine';
import AddMedicine from './Components/AdminMedicine/AddMedicine';
import MedicineList from './Components/AdminMedicine/MedicineList';
import Footer from './Components/Footer/Footer';

function App() {

  return (
    <Router>
      <div className="App">
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/login" component={Login} />
          <Route path="/Home" exact component={Home} />
          <Route path="/loginadmin" component={LoginAdmin} />
          <Route path="/Registration" component={Registration} />
          <Route path="/Medicine" component={Medicine} />
          <Route path="/AddMedicine" component={AddMedicine} />
          <Route path="/MedicineList" component={MedicineList} />
        </Switch>
        <Footer/>
      </div>
    </Router>
  );
}

export default App;
